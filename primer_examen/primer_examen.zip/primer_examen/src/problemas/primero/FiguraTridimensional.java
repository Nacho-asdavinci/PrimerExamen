package problemas.primero;

public abstract class FiguraTridimensional {


    public final static int dimensiones = 3;



    public abstract double calcularVolumen();

    public abstract double calcularSuperficie();



}

